import React from 'react';
export const SearchBar: React.FC<{onSearch:(q:string)=>void}> = ({onSearch})=>{
  const [q,setQ]=React.useState('');
  return (
    <div style={{display:'flex',gap:8,alignItems:'center'}}>
      <input className="search" placeholder="Search movies..." value={q} onChange={e=>setQ(e.target.value)} />
      <button className="btn primary" onClick={()=>onSearch(q)}>Search</button>
    </div>
  )
}
export default SearchBar;