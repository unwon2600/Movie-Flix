import React from 'react';
export const AddMovieForm: React.FC<{onAdd:(m:any)=>void, onClose?:()=>void}> = ({onAdd,onClose}) => {
  const [title,setTitle]=React.useState('');
  const [poster,setPoster]=React.useState('');
  const [desc,setDesc]=React.useState('');
  const [year,setYear]=React.useState<number|''>('');
  const [tags,setTags]=React.useState('');
  return (
    <div className="card">
      <h3 style={{marginTop:0}}>Add Movie</h3>
      <div style={{display:'grid',gap:8,gridTemplateColumns:'1fr 1fr'}}>
        <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
        <input placeholder="Poster URL" value={poster} onChange={e=>setPoster(e.target.value)} />
        <input placeholder="Year" value={year as any} onChange={e=>setYear(e.target.value?parseInt(e.target.value):'')} />
        <input placeholder="Tags (comma separated)" value={tags} onChange={e=>setTags(e.target.value)} />
        <textarea placeholder="Short description" value={desc} onChange={e=>setDesc(e.target.value)} style={{gridColumn:'1/-1'}} />
      </div>
      <div style={{display:'flex',gap:8,marginTop:10,justifyContent:'flex-end'}}>
        <button className="btn ghost" onClick={()=>{onClose && onClose()}}>Cancel</button>
        <button className="btn primary" onClick={()=>{
          if(!title) return alert('Title required');
          onAdd({id:Date.now().toString(),title,poster,description:desc,year:year||undefined,tags: tags?tags.split(',').map(s=>s.trim()):[]});
          setTitle('');setPoster('');setDesc('');setYear('');setTags('');
          onClose && onClose();
        }}>Add Movie</button>
      </div>
    </div>
  )
}
export default AddMovieForm;