import React from 'react';
import MovieCard from './MovieCard';
export const MovieList: React.FC<{movies:any[], onDownload?: (m:any)=>void}> = ({movies,onDownload}) => {
  if(!movies || movies.length===0){
    return <div className="card">No movies yet. Use <b>Add Movie</b> to populate.</div>
  }
  return (
    <section className="grid">
      {movies.map(m=>(
        <MovieCard key={m.id || m.title} movie={m} onDownload={onDownload} />
      ))}
    </section>
  )
}
export default MovieList;