import React from 'react';
type Movie = { id:string; title:string; poster?:string; description?:string; year?:number; tags?:string[] };
const fallback = "https://via.placeholder.com/400x600?text=No+Image";
export const MovieCard: React.FC<{movie:Movie, onDownload?: (m:Movie)=>void}> = ({movie,onDownload}) => {
  return (
    <article className="card movie-card">
      <img className="movie-poster" src={movie.poster || fallback} alt={movie.title} onError={(e:any)=>{e.currentTarget.src=fallback}} />
      <div className="movie-body">
        <div className="title-row">
          <div>
            <div className="title">{movie.title}</div>
            <div className="meta">{movie.year || '—'}</div>
          </div>
          <div style={{textAlign:'right'}}>
            <div className="meta">HD · 2h</div>
          </div>
        </div>
        <div className="tags">
          {(movie.tags||[]).slice(0,4).map((t,i)=>(<div key={i} className="tag">{t}</div>))}
        </div>
        <div style={{fontSize:14,color:'#cfe7ff',opacity:0.9}}>{movie.description ? (movie.description.length>140? movie.description.slice(0,140)+'...':movie.description) : 'No description provided.'}</div>
        <div className="card-actions">
          <button className="btn ghost small" onClick={()=>window.alert('Open details for '+movie.title)}>View</button>
          <button className="btn primary small" onClick={()=>onDownload && onDownload(movie)}>Download</button>
        </div>
      </div>
    </article>
  )
}
export default MovieCard;