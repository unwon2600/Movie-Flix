import React from 'react';

export const Header: React.FC<{onOpenAdd: ()=>void, onSearch: (q:string)=>void}> = ({onOpenAdd, onSearch}) => {
  const [q, setQ] = React.useState('');
  return (
    <header className="header">
      <div className="brand">
        <div className="logo">MF</div>
        <div>
          <div className="site-title">MovieFlix — Professional</div>
          <div style={{fontSize:12,color:'#94a3b8'}}>Streamlined. Fast. Mobile-first.</div>
        </div>
      </div>
      <div className="controls">
        <div className="search card" style={{display:'flex',alignItems:'center'}}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M21 21l-4.35-4.35" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>
          <input placeholder="Search movies, actors, genres..." value={q} onChange={e=>setQ(e.target.value)} />
          <button className="btn ghost small" onClick={()=>onSearch(q)}>Search</button>
        </div>
        <button className="btn primary" onClick={onOpenAdd}>+ Add Movie</button>
      </div>
    </header>
  );
}
export default Header;